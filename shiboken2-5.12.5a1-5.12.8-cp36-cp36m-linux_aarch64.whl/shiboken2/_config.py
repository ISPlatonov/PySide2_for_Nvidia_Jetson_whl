shiboken_library_soversion = str(5.12)

version = "5.12.5a1"
version_info = (5, 12, 5, "a", "1")

__build_date__ = '2022-02-03T18:02:57+00:00'
__build_commit_date__ = '2020-06-12T14:41:08+00:00'
__build_commit_hash__ = '0395817102e9b8601c93e60349360fcdd8a3c66d'
__build_commit_hash_described__ = 'v5.11.2-554-g039581710'

__setup_py_package_version__ = '5.12.5a1'
